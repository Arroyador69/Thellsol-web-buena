# TellSol Real Estate

Sitio web estático para la inmobiliaria TellSol, listo para desplegar en GitHub Pages y conectar con tu dominio personalizado en Hostinger.

## Estructura
- `index.html`: Página principal
- `images/`: Carpeta con todas las imágenes usadas en la web

## Publicación
1. Sube este contenido a un repositorio de GitHub (por ejemplo, `thellsol.github.io`).
2. Activa GitHub Pages en la rama `main` y carpeta raíz (`/`).
3. (Opcional) Añade un archivo `CNAME` con tu dominio personalizado.
4. Apunta los DNS de tu dominio en Hostinger a GitHub Pages.

¡Listo para estar online! 